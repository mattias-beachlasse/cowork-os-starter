@echo off
cd /d "%~dp0"
echo Starting the cockpit in LIVE-SAVE mode (click-free auto-save to tasks.csv).
echo Opening http://localhost:8753/cowork-cockpit.html in your browser.
echo Keep the PowerShell window that appears open while you use the board.
start "Cockpit live-save server" powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tasks-server.ps1"
rem Give the server a moment to bind before opening the browser (avoids ERR_CONNECTION_REFUSED on first load).
timeout /t 2 /nobreak >nul
start "" "http://localhost:8753/cowork-cockpit.html"
