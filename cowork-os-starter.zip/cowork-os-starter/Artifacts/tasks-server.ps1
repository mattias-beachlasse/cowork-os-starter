# Cockpit live-save helper (PowerShell — always available on Windows).
# Serves this folder, answers GET /health, and writes whitelisted CSVs.
#   POST /save-tasks                  -> tasks.csv          (kept for back-compat)
#   POST /save?file=tasks.csv         -> tasks.csv
#   POST /save?file=player_profiles.csv -> player_profiles.csv
#   POST /save?file=deadlines           -> Tasks\deadlines.csv (plaintext)
#   POST /save?file=travel-vault        -> Travel\travel_vault.enc.json
#                                          (opaque client-encrypted blob; server
#                                           stores ciphertext only, never the key)
# Any other file identifier is refused (400).

# --- Hub-index refresh hook (Felix) --------------------------------------
# Fire-and-forget the index refresh at login. This runs HIDDEN and is fully
# isolated in try/catch: any failure here (missing script, no Python, etc.)
# is swallowed so it can NEVER stop the cockpit server below from binding.
# We do NOT -Wait — the refresh runs in the background while the server
# starts, so it never delays the port bind.
try {
  $refreshScript = (Join-Path (Split-Path $PSScriptRoot -Parent) 'SetupRefresh-Hub-Index.ps1')
  if (Test-Path -LiteralPath $refreshScript -PathType Leaf) {
    Start-Process -FilePath 'powershell' `
      -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File',$refreshScript) `
      -WindowStyle Hidden | Out-Null
  }
} catch { }

$port  = 8753
$root  = $PSScriptRoot

# --- Auth token + Origin/Host allowlists (added v10) ----------------------
# The cockpit is a same-origin page served by THIS server. To let it talk to
# the mutating endpoints while keeping random websites out, every sensitive
# endpoint requires a shared secret in the X-Cockpit-Token header, and we lock
# down Origin/Host to a small allowlist (DNS-rebinding + CSRF defense). The
# secret lives next to this script so the cockpit can fetch it via /token
# (which is itself gated by the same-origin Origin check).
$tokenHeaderName = 'X-Cockpit-Token'
$tokenFile = Join-Path $PSScriptRoot '.cockpit-token'
$cockpitToken = $null
try {
  if (Test-Path $tokenFile -PathType Leaf) {
    $cockpitToken = ([IO.File]::ReadAllText($tokenFile)).Trim()
  }
} catch { $cockpitToken = $null }
if ([string]::IsNullOrWhiteSpace($cockpitToken)) {
  # Generate a fresh random secret (two GUIDs => long, hard-to-guess) and
  # persist it as UTF-8 without BOM so it round-trips cleanly.
  $cockpitToken = ([guid]::NewGuid().ToString('N') + [guid]::NewGuid().ToString('N'))
  try { [IO.File]::WriteAllText($tokenFile, $cockpitToken, (New-Object Text.UTF8Encoding($false))) } catch {}
}

# Allowlisted Origins (exact, scheme+host+port). The cockpit is served from
# these. To expose this over a Tailscale tunnel later, add the tunnel origin
# here, e.g. 'http://my-host.tail-scale.ts.net:8753'  <-- ADD TUNNEL ORIGIN HERE.
$allowedOrigins = @(
  'http://localhost:8753',
  'http://127.0.0.1:8753'
  # ,'http://<tunnel-host>:8753'   <-- ADD TAILSCALE TUNNEL ORIGIN HERE
)
# Allowlisted Host headers (host[:port]). Blunts DNS-rebinding against this
# loopback service: a rebound domain would arrive with a non-allowlisted Host.
# Add the Tailscale hostname here when exposing the tunnel.
$allowedHosts = @(
  'localhost:8753',
  '127.0.0.1:8753'
  # ,'<tunnel-host>:8753'          <-- ADD TAILSCALE TUNNEL HOST HERE
)

# True if the request Origin is absent (same-origin / non-CORS) OR allowlisted.
function Test-OriginAllowed($req) {
  $o = $req.Headers['Origin']
  if ([string]::IsNullOrEmpty($o)) { return $true }   # no Origin = same-origin/local
  return ($allowedOrigins -contains $o)
}
# True if the request Host header is on the allowlist (case-insensitive).
function Test-HostAllowed($req) {
  $h = $req.Headers['Host']
  if ([string]::IsNullOrEmpty($h)) { return $false }
  foreach ($a in $allowedHosts) { if ($h.Equals($a, [StringComparison]::OrdinalIgnoreCase)) { return $true } }
  return $false
}
# True if the request carries the correct secret token.
function Test-TokenValid($req) {
  $t = $req.Headers[$tokenHeaderName]
  if ([string]::IsNullOrEmpty($t)) { return $false }
  return ($t -ceq $cockpitToken)
}
# Apply CORS headers: echo the Origin back ONLY if allowlisted (never '*'),
# and always advertise Vary: Origin so caches don't cross origins.
function Set-CorsHeaders($req, $res) {
  $res.Headers.Add('Vary','Origin')
  $o = $req.Headers['Origin']
  if (-not [string]::IsNullOrEmpty($o) -and ($allowedOrigins -contains $o)) {
    $res.Headers.Add('Access-Control-Allow-Origin', $o)
    $res.Headers.Add('Access-Control-Allow-Methods','GET,POST,OPTIONS')
    $res.Headers.Add("Access-Control-Allow-Headers","Content-Type,$tokenHeaderName")
  }
}

# Hub root = the folder that CONTAINS this Artifacts folder. Derived from the
# script's OWN location so the whole bundle is portable: wherever it sits, the
# data folders (Tasks, National Team, The Beach, ...) resolve as siblings of
# Artifacts. On the author's machine this resolved to the hub root exactly as
# before; on any copy it resolves to wherever the copy lives, with no junction.
# Also the hub root for the read-only Files browser endpoints (/list, /file,
# /open). Everything those touch MUST resolve INSIDE this folder, see Resolve-HubPath.
$hubRoot = Split-Path $PSScriptRoot -Parent
function Hub([string]$rel) { Join-Path $hubRoot $rel }

$tasks = Hub 'Tasks\tasks.csv'

# Whitelist of writable targets. Key = file identifier sent by the client,
# value = absolute destination path. Nothing outside this map is ever written.
$saveTargets = @{
  'tasks.csv'                    = (Hub 'Tasks\tasks.csv')
  'player_profiles.csv'          = (Hub 'National Team\Team Database\player_profiles.csv')
  # Companion *_profiles.csv files (one per entity), the editable-detail framework.
  'members_profiles.csv'         = (Hub 'The Beach\Member Database\members_profiles.csv')
  'groups_profiles.csv'          = (Hub 'The Beach\Member Database\groups_profiles.csv')
  'memberships_profiles.csv'     = (Hub 'The Beach\Member Database\memberships_profiles.csv')
  'payments_profiles.csv'        = (Hub 'The Beach\Member Database\payments_profiles.csv')
  'camps_profiles.csv'           = (Hub 'National Team\Team Database\camps_profiles.csv')
  'attendance_profiles.csv'      = (Hub 'National Team\Team Database\attendance_profiles.csv')
  'contacts_profiles.csv'        = (Hub 'Federation\Federation Database\contacts_profiles.csv')
  'wildcard_cases_profiles.csv'  = (Hub 'Federation\Federation Database\wildcard_cases_profiles.csv')
  'trips_profiles.csv'           = (Hub 'BeachTravels\Trip Database\trips_profiles.csv')
  'participants_profiles.csv'    = (Hub 'BeachTravels\Trip Database\participants_profiles.csv')
  'bookings_profiles.csv'        = (Hub 'BeachTravels\Trip Database\bookings_profiles.csv')
  'sessions_profiles.csv'        = (Hub 'Health & Fitness\Fitness Log\sessions_profiles.csv')
  'bodyweight_profiles.csv'      = (Hub 'Health & Fitness\Fitness Log\bodyweight_profiles.csv')
  'nutrition_profiles.csv'       = (Hub 'Health & Fitness\Fitness Log\nutrition_profiles.csv')
  'injuries_profiles.csv'        = (Hub 'Health & Fitness\Fitness Log\injuries_profiles.csv')
  # Activity log, append-style companion written by the cockpit on every live save.
  'activity_log.csv'             = (Hub 'Tasks\activity_log.csv')
  # Projects board, live-loaded and live-saved by the cockpit (Projects tracker).
  'projects.csv'                 = (Hub 'Tasks\projects.csv')
  # Quick-capture inbox, live-loaded and live-saved by the cockpit (Inbox capture/triage, #6).
  'inbox.csv'                    = (Hub 'Tasks\inbox.csv')
  # Player results, read-only in the cockpit, written by a weekly scheduled task.
  'player_results.csv'           = (Hub 'National Team\Team Database\player_results.csv')
  # Deadline & Entry Sentinel — plaintext (non-sensitive) irreversible deadlines.
  'deadlines'                    = (Hub 'Tasks\deadlines.csv')
  # Squad Travel & Passport Hub — CLIENT-SIDE ENCRYPTED vault (AES-GCM). The body
  # is an opaque JSON/base64 envelope, NOT CSV: Save-Csv writes it as raw UTF-8
  # text with no CSV assumptions, and /file reads it back byte-for-byte. The
  # server never sees the passphrase and cannot decrypt this — it only stores
  # ciphertext. Stays behind X-Cockpit-Token like every other write.
  'travel-vault'                 = (Hub 'Travel\travel_vault.enc.json')
  # Cockpit shared config — rules / filters / saved views, so they MIRROR across
  # laptops via the Drive-synced hub. Raw JSON text (plaintext, non-sensitive):
  # written byte-for-byte through Save-Csv exactly like the travel vault (NOT
  # CSV-parsed), and read back via /file. Stays behind X-Cockpit-Token.
  'cockpit-config'               = (Hub 'Tasks\cockpit_config.json')
}

# Separate whitelist of CANONICAL CSVs. Used ONLY by the backup+write delete
# path (POST /save?file=<id>&backup=1). A dated .bak copy is taken BEFORE the
# new contents overwrite the file, so a confirmed delete is always recoverable.
# These are intentionally NOT in $saveTargets — canonical data is never written
# except through the explicit, confirmed, backup-first delete path.
$canonicalTargets = @{
  'players.csv'        = (Hub 'National Team\Team Database\players.csv')
  'camps.csv'          = (Hub 'National Team\Team Database\camps.csv')
  'attendance.csv'     = (Hub 'National Team\Team Database\attendance.csv')
  'members.csv'        = (Hub 'The Beach\Member Database\members.csv')
  'groups.csv'         = (Hub 'The Beach\Member Database\groups.csv')
  'memberships.csv'    = (Hub 'The Beach\Member Database\memberships.csv')
  'payments.csv'       = (Hub 'The Beach\Member Database\payments.csv')
  'contacts.csv'       = (Hub 'Federation\Federation Database\contacts.csv')
  'wildcard_cases.csv' = (Hub 'Federation\Federation Database\wildcard_cases.csv')
  'trips.csv'          = (Hub 'BeachTravels\Trip Database\trips.csv')
  'participants.csv'   = (Hub 'BeachTravels\Trip Database\participants.csv')
  'bookings.csv'       = (Hub 'BeachTravels\Trip Database\bookings.csv')
  'sessions.csv'       = (Hub 'Health & Fitness\Fitness Log\sessions.csv')
  'bodyweight.csv'     = (Hub 'Health & Fitness\Fitness Log\bodyweight.csv')
  'nutrition.csv'      = (Hub 'Health & Fitness\Fitness Log\nutrition.csv')
  'injuries.csv'       = (Hub 'Health & Fitness\Fitness Log\injuries.csv')
}

# Write helper: forces UTF-8 (no BOM) and creates the parent dir if missing.
function Save-Csv($dest, $body) {
  $dir = Split-Path $dest
  if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
  [IO.File]::WriteAllText($dest, $body, (New-Object Text.UTF8Encoding($false)))
}

# Backup helper: copy the current file to <name>.bak-<yyyyMMddHHmm>.csv in the
# same folder, BEFORE any overwrite. No-op (returns $true) if the file doesn't
# exist yet — nothing to lose. Returns $false only if an existing file could
# not be backed up, in which case the caller MUST refuse the overwrite.
function Backup-Csv($dest) {
  try {
    if (-not (Test-Path $dest -PathType Leaf)) { return $true }
    $dir  = Split-Path $dest
    $base = [IO.Path]::GetFileNameWithoutExtension($dest)
    $ext  = [IO.Path]::GetExtension($dest)
    $stamp = (Get-Date).ToString('yyyyMMddHHmm')
    $bak  = Join-Path $dir ("$base.bak-$stamp$ext")
    Copy-Item -LiteralPath $dest -Destination $bak -Force
    return (Test-Path $bak -PathType Leaf)
  } catch { return $false }
}

# --- Files-browser path guard --------------------------------------------
# Resolve a client-supplied RELATIVE path against the hub root and refuse
# anything that escapes it. Returns the absolute path on success, or $null
# if the request is unsafe (absolute/rooted, contains '..', or resolves
# outside $hubRoot). Empty / '.' / '/' means the hub root itself.
function Resolve-HubPath([string]$rel) {
  if ($null -eq $rel) { $rel = '' }
  $rel = $rel.Trim()
  # normalise separators and strip leading slashes so 'a/b' and '/a/b' match
  $rel = $rel -replace '/', '\'
  $rel = $rel.TrimStart('\')
  if ($rel -eq '' -or $rel -eq '.') { return $hubRoot }
  # reject explicit traversal and absolute/rooted inputs outright
  if ($rel -match '(^|\\)\.\.(\\|$)') { return $null }   # any '..' segment
  if ($rel -match '^[A-Za-z]:') { return $null }          # drive-letter rooted
  if ($rel -match '^\\\\') { return $null }               # UNC path
  $full = $null
  try { $full = [IO.Path]::GetFullPath([IO.Path]::Combine($hubRoot, $rel)) } catch { return $null }
  # final containment check (case-insensitive); allow the root itself or any child
  $rootFull = [IO.Path]::GetFullPath($hubRoot).TrimEnd('\')
  if ($full.TrimEnd('\').Equals($rootFull, [StringComparison]::OrdinalIgnoreCase)) { return $full }
  if (-not $full.StartsWith($rootFull + '\', [StringComparison]::OrdinalIgnoreCase)) { return $null }
  return $full
}

# Skip hidden/system/junk entries in directory listings.
function Test-HiddenName([string]$name) {
  if ([string]::IsNullOrEmpty($name)) { return $true }
  if ($name.StartsWith('.')) { return $true }
  if ($name.StartsWith('$')) { return $true }
  if ($name -eq '.tmp.driveupload') { return $true }
  return $false
}

# Minimal JSON string escaper (PS 5.1-safe; avoids ConvertTo-Json quirks).
function ConvertTo-JsonString([string]$s) {
  if ($null -eq $s) { return '""' }
  $sb = New-Object Text.StringBuilder
  [void]$sb.Append('"')
  foreach ($ch in $s.ToCharArray()) {
    switch ($ch) {
      '"'  { [void]$sb.Append('\"') }
      '\'  { [void]$sb.Append('\\') }
      "`b" { [void]$sb.Append('\b') }
      "`f" { [void]$sb.Append('\f') }
      "`n" { [void]$sb.Append('\n') }
      "`r" { [void]$sb.Append('\r') }
      "`t" { [void]$sb.Append('\t') }
      default {
        if ([int]$ch -lt 32) { [void]$sb.Append(('\u{0:x4}' -f [int]$ch)) }
        else { [void]$sb.Append($ch) }
      }
    }
  }
  [void]$sb.Append('"')
  return $sb.ToString()
}

$types = @{ '.html'='text/html; charset=utf-8'; '.csv'='text/csv; charset=utf-8';
            '.js'='text/javascript'; '.css'='text/css'; '.json'='application/json';
            '.jpg'='image/jpeg'; '.jpeg'='image/jpeg'; '.png'='image/png';
            '.webp'='image/webp'; '.gif'='image/gif'; '.svg'='image/svg+xml';
            '.pdf'='application/pdf'; '.txt'='text/plain; charset=utf-8';
            '.md'='text/plain; charset=utf-8'; '.mp4'='video/mp4'; '.webm'='video/webm' }

# Whitelist of file extensions /open is allowed to launch via the shell's
# default action. Folders are always allowed (opened in Explorer). Anything
# NOT in this set — especially executables/scripts (.exe .bat .ps1 .cmd .vbs
# .lnk .hta .msi .js ...) — is refused with 403, so /open can never be used to
# run arbitrary code.
$openableExts = @('.csv','.txt','.md','.pdf','.png','.jpg','.jpeg','.gif','.webp','.docx','.xlsx','.pptx','.html')

# --- Take over from any previous instance, thoroughly, before binding ---
# 1) Stop whatever is listening on our port — but ONLY if that PID is actually
#    a PowerShell process running THIS script. We intersect the NetTCP owner
#    PIDs with the CIM CommandLine match so an unrelated process that happens
#    to hold the port (or has reused a stale PID) is never force-killed.
try {
  $portPids = @(
    Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue |
      Select-Object -ExpandProperty OwningProcess -ErrorAction SilentlyContinue
  ) | Sort-Object -Unique
  if ($portPids.Count -gt 0) {
    $ourServerPids = @(
      Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
        Where-Object { $_.CommandLine -like '*tasks-server.ps1*' } |
        Select-Object -ExpandProperty ProcessId
    )
    foreach ($pp in $portPids) {
      if (($ourServerPids -contains $pp) -and ($pp -ne $PID)) {
        Stop-Process -Id $pp -Force -ErrorAction SilentlyContinue
      }
    }
  }
} catch {}

# 2) Stop any OTHER PowerShell process running THIS script, excluding ourselves ($PID).
#    The in-script port kill can lose the race or miss a process that hasn't bound yet,
#    so we also match on command line via CIM/WMI.
try {
  Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
    Where-Object { $_.ProcessId -ne $PID -and $_.CommandLine -like '*tasks-server.ps1*' } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
} catch {}

Start-Sleep -Milliseconds 300

# --- Retry the bind: a slow socket release should NOT make the new instance give up. ---
$listener = $null
$started  = $false
for ($attempt = 1; $attempt -le 10; $attempt++) {
  try {
    $listener = New-Object System.Net.HttpListener
    $listener.Prefixes.Add("http://127.0.0.1:$port/")
    $listener.Start()
    $started = $true
    break
  } catch {
    if ($listener) { try { $listener.Close() } catch {} }
    $listener = $null
    Start-Sleep -Milliseconds 400
  }
}
if (-not $started) {
  Write-Host "Could not start the server on port $port after multiple attempts. Is it already running?"
  Read-Host "Press Enter to close"; exit 1
}
Write-Host "Cockpit live-save server running on http://localhost:$port"
Write-Host "Saving to: $tasks"
Write-Host "Keep this window open while you use the board. Close it to stop."

while ($listener.IsListening) {
  try {
    $ctx = $listener.GetContext()
    $req = $ctx.Request
    $res = $ctx.Response
    # CORS: echo allowlisted Origin only (never '*'), advertise Vary: Origin and
    # the X-Cockpit-Token header. Replaces the old wildcard ACAO (added v10).
    Set-CorsHeaders $req $res
    $path = [Uri]::UnescapeDataString($req.Url.AbsolutePath)

    if ($req.HttpMethod -eq 'OPTIONS') { $res.StatusCode = 204; $res.Close(); continue }

    # /health stays OPEN (no secret, no token) so the cockpit and launcher can
    # probe liveness before they have a token.
    if ($path -eq '/health') {
      $b = [Text.Encoding]::UTF8.GetBytes('{"ok":true,"version":13,"auth":true,"targets":["tasks.csv","player_profiles.csv","members_profiles.csv","groups_profiles.csv","memberships_profiles.csv","payments_profiles.csv","camps_profiles.csv","attendance_profiles.csv","contacts_profiles.csv","wildcard_cases_profiles.csv","trips_profiles.csv","participants_profiles.csv","bookings_profiles.csv","sessions_profiles.csv","bodyweight_profiles.csv","nutrition_profiles.csv","injuries_profiles.csv","activity_log.csv","projects.csv","inbox.csv","player_results.csv","deadlines","travel-vault","cockpit-config"],"canonical":["players.csv","camps.csv","attendance.csv","members.csv","groups.csv","memberships.csv","payments.csv","contacts.csv","wildcard_cases.csv","trips.csv","participants.csv","bookings.csv","sessions.csv","bodyweight.csv","nutrition.csv","injuries.csv"]}')
      $res.ContentType = 'application/json'; $res.OutputStream.Write($b,0,$b.Length); $res.Close(); continue
    }

    # ---- GET /token : hand the secret to the same-origin cockpit only --------
    # Gated by the Origin check (NOT by the token itself — this is how the page
    # bootstraps). Served when the request has NO Origin (same-origin / local)
    # or an allowlisted Origin. A cross-site fetch from a random website carries
    # a non-allowlisted Origin and gets 403 with no token.
    if ($req.HttpMethod -eq 'GET' -and $path -eq '/token') {
      if (-not (Test-OriginAllowed $req)) {
        $res.StatusCode = 403
        $b = [Text.Encoding]::UTF8.GetBytes('{"error":"forbidden origin"}')
        $res.ContentType = 'application/json'; $res.OutputStream.Write($b,0,$b.Length); $res.Close(); continue
      }
      $json = '{"token":' + (ConvertTo-JsonString $cockpitToken) + '}'
      $b = [Text.Encoding]::UTF8.GetBytes($json)
      $res.ContentType = 'application/json'; $res.OutputStream.Write($b,0,$b.Length); $res.Close(); continue
    }

    # ---- Gate for all sensitive/mutating endpoints (added v10) ---------------
    # Order of checks: Host/Origin allowlist (DNS-rebinding/CSRF) -> token ->
    # handler. /health and /token are handled above and never reach here; the
    # static-file GET below is intentionally left OPEN so the page/assets load.
    $gatedPaths = @('/save','/save-tasks','/open','/stat','/file','/list')
    if ($gatedPaths -contains $path) {
      if (-not (Test-HostAllowed $req) -or -not (Test-OriginAllowed $req)) {
        $res.StatusCode = 403
        $b = [Text.Encoding]::UTF8.GetBytes('{"error":"forbidden host/origin"}')
        $res.ContentType = 'application/json'; $res.OutputStream.Write($b,0,$b.Length); $res.Close(); continue
      }
      if (-not (Test-TokenValid $req)) {
        $res.StatusCode = 401
        $b = [Text.Encoding]::UTF8.GetBytes('{"error":"missing or invalid token"}')
        $res.ContentType = 'application/json'; $res.OutputStream.Write($b,0,$b.Length); $res.Close(); continue
      }
    }

    # ---- Cheap read-only stat: GET /stat?file=<id> --------------------------
    # Returns mtime (epoch ms) + size for any writable ($saveTargets) or
    # canonical ($canonicalTargets) file id. Used by the cockpit's multi-device
    # save-guard to detect when another device changed the file since load.
    # Unknown id -> 400 {"ok":false}. File not yet on disk -> mtime:0,size:0.
    # Read-only: never writes, never backs up. Reuses the existing whitelists.
    if ($req.HttpMethod -eq 'GET' -and $path -eq '/stat') {
      $fileId = $req.QueryString['file']
      $dest = $null
      if ($fileId -and $saveTargets.ContainsKey($fileId)) { $dest = $saveTargets[$fileId] }
      elseif ($fileId -and $canonicalTargets.ContainsKey($fileId)) { $dest = $canonicalTargets[$fileId] }
      if (-not $dest) {
        $res.StatusCode = 400
        $b = [Text.Encoding]::UTF8.GetBytes('{"ok":false,"error":"unknown file"}')
        $res.ContentType = 'application/json'; $res.OutputStream.Write($b,0,$b.Length); $res.Close(); continue
      }
      $mtime = 0; $size = 0
      try {
        if (Test-Path $dest -PathType Leaf) {
          # Get-Item can hand back a single-element collection; force a scalar
          # FileInfo with @(...)[0] so .Length is the real byte length, never the
          # collection count (the old code reported size=1 for multi-line files).
          $fi = @(Get-Item -LiteralPath $dest -ErrorAction Stop)[0]
          $mtime = [long][Math]::Floor((($fi.LastWriteTimeUtc) - (Get-Date '1970-01-01T00:00:00Z').ToUniversalTime()).TotalMilliseconds)
          # Authoritative byte length straight off the FileInfo property.
          $size  = [long]($fi.Length)
        }
      } catch { $mtime = 0; $size = 0 }
      $json = '{"ok":true,"file":' + (ConvertTo-JsonString $fileId) + ',"mtime":' + $mtime + ',"size":' + $size + '}'
      $b = [Text.Encoding]::UTF8.GetBytes($json)
      $res.ContentType = 'application/json'; $res.OutputStream.Write($b,0,$b.Length); $res.Close(); continue
    }

    # Back-compat: original tasks endpoint. Now refuses an empty/whitespace body
    # (an empty POST used to truncate tasks.csv) and backs up first like the
    # canonical path, so a bad save is always recoverable.
    if ($req.HttpMethod -eq 'POST' -and $path -eq '/save-tasks') {
      $reader = New-Object IO.StreamReader($req.InputStream, [Text.Encoding]::UTF8)
      $body = $reader.ReadToEnd(); $reader.Close()
      if ([string]::IsNullOrWhiteSpace($body)) {
        $res.StatusCode = 400
        $b = [Text.Encoding]::UTF8.GetBytes('{"saved":false,"error":"empty body refused"}')
        $res.ContentType = 'application/json'; $res.OutputStream.Write($b,0,$b.Length); $res.Close(); continue
      }
      if (-not (Backup-Csv $tasks)) {
        $res.StatusCode = 500
        $b = [Text.Encoding]::UTF8.GetBytes('{"saved":false,"error":"backup failed"}')
        $res.ContentType = 'application/json'; $res.OutputStream.Write($b,0,$b.Length); $res.Close(); continue
      }
      Save-Csv $tasks $body
      $b = [Text.Encoding]::UTF8.GetBytes('{"saved":true}')
      $res.ContentType = 'application/json'; $res.OutputStream.Write($b,0,$b.Length); $res.Close(); continue
    }

    # Generalised whitelisted save: POST /save?file=<id>[&backup=1]
    #   backup=1 -> CANONICAL delete/rewrite path: resolve against the
    #              $canonicalTargets whitelist, take a dated .bak FIRST, then
    #              overwrite. Used only by the cockpit's confirmed-delete flow.
    #   (no flag) -> companion/tasks save against $saveTargets, unchanged.
    if ($req.HttpMethod -eq 'POST' -and $path -eq '/save') {
      $fileId = $req.QueryString['file']
      $wantBackup = ($req.QueryString['backup'] -eq '1')
      $dest = $null
      if ($wantBackup) {
        if ($fileId -and $canonicalTargets.ContainsKey($fileId)) { $dest = $canonicalTargets[$fileId] }
      } else {
        if ($fileId -and $saveTargets.ContainsKey($fileId)) { $dest = $saveTargets[$fileId] }
      }
      if (-not $dest) {
        $res.StatusCode = 400
        $b = [Text.Encoding]::UTF8.GetBytes('{"saved":false,"error":"unknown file"}')
        $res.ContentType = 'application/json'; $res.OutputStream.Write($b,0,$b.Length); $res.Close(); continue
      }
      $reader = New-Object IO.StreamReader($req.InputStream, [Text.Encoding]::UTF8)
      $body = $reader.ReadToEnd(); $reader.Close()
      # Guard: never let an empty/whitespace body wipe a canonical file. A valid
      # rewrite always carries at least the header row.
      if ($wantBackup -and [string]::IsNullOrWhiteSpace($body)) {
        $res.StatusCode = 400
        $b = [Text.Encoding]::UTF8.GetBytes('{"saved":false,"error":"empty body refused"}')
        $res.ContentType = 'application/json'; $res.OutputStream.Write($b,0,$b.Length); $res.Close(); continue
      }
      # Backup FIRST. If an existing canonical file can't be backed up, refuse
      # to overwrite it — better to fail the delete than to lose data.
      if ($wantBackup) {
        if (-not (Backup-Csv $dest)) {
          $res.StatusCode = 500
          $b = [Text.Encoding]::UTF8.GetBytes('{"saved":false,"error":"backup failed"}')
          $res.ContentType = 'application/json'; $res.OutputStream.Write($b,0,$b.Length); $res.Close(); continue
        }
      }
      Save-Csv $dest $body
      $b = [Text.Encoding]::UTF8.GetBytes('{"saved":true}')
      $res.ContentType = 'application/json'; $res.OutputStream.Write($b,0,$b.Length); $res.Close(); continue
    }

    # ---- Files browser: GET /list?dir=<relpath> (hub-root scoped) ----
    if ($req.HttpMethod -eq 'GET' -and $path -eq '/list') {
      $reqDir = $req.QueryString['dir']
      $abs = Resolve-HubPath $reqDir
      if (-not $abs -or -not (Test-Path $abs -PathType Container)) {
        $res.StatusCode = 400
        $b = [Text.Encoding]::UTF8.GetBytes('{"error":"bad path"}')
        $res.ContentType = 'application/json'; $res.OutputStream.Write($b,0,$b.Length); $res.Close(); continue
      }
      # relative form for echo: strip the hub root prefix, normalise to forward slashes
      $rootFull = [IO.Path]::GetFullPath($hubRoot).TrimEnd('\')
      $relOut = $abs.Substring([Math]::Min($abs.Length, $rootFull.Length)).TrimStart('\') -replace '\\','/'
      $folders = @(); $files = @()
      try {
        Get-ChildItem -LiteralPath $abs -Directory -ErrorAction SilentlyContinue | ForEach-Object {
          if (-not (Test-HiddenName $_.Name)) { $folders += $_ }
        }
        Get-ChildItem -LiteralPath $abs -File -ErrorAction SilentlyContinue | ForEach-Object {
          if (-not (Test-HiddenName $_.Name)) { $files += $_ }
        }
      } catch {}
      $folders = $folders | Sort-Object Name
      $files   = $files   | Sort-Object Name
      $sb = New-Object Text.StringBuilder
      [void]$sb.Append('{"dir":'); [void]$sb.Append((ConvertTo-JsonString $relOut)); [void]$sb.Append(',"folders":[')
      $first = $true
      foreach ($d in $folders) {
        if (-not $first) { [void]$sb.Append(',') }
        [void]$sb.Append('{"name":'); [void]$sb.Append((ConvertTo-JsonString $d.Name)); [void]$sb.Append('}')
        $first = $false
      }
      [void]$sb.Append('],"files":[')
      $first = $true
      foreach ($f in $files) {
        if (-not $first) { [void]$sb.Append(',') }
        $ext = $f.Extension.TrimStart('.').ToLower()
        $modified = $f.LastWriteTime.ToString('yyyy-MM-dd HH:mm')
        [void]$sb.Append('{"name":'); [void]$sb.Append((ConvertTo-JsonString $f.Name))
        [void]$sb.Append(',"ext":'); [void]$sb.Append((ConvertTo-JsonString $ext))
        [void]$sb.Append(',"size":'); [void]$sb.Append([long]$f.Length)
        [void]$sb.Append(',"modified":'); [void]$sb.Append((ConvertTo-JsonString $modified))
        [void]$sb.Append('}')
        $first = $false
      }
      [void]$sb.Append(']}')
      $b = [Text.Encoding]::UTF8.GetBytes($sb.ToString())
      $res.ContentType = 'application/json'; $res.OutputStream.Write($b,0,$b.Length); $res.Close(); continue
    }

    # ---- Files browser: GET /file?path=<relpath> (raw bytes, for previews) ----
    if ($req.HttpMethod -eq 'GET' -and $path -eq '/file') {
      $abs = Resolve-HubPath $req.QueryString['path']
      if (-not $abs -or -not (Test-Path $abs -PathType Leaf)) {
        $res.StatusCode = 404
        $b = [Text.Encoding]::UTF8.GetBytes('{"error":"not found"}')
        $res.ContentType = 'application/json'; $res.OutputStream.Write($b,0,$b.Length); $res.Close(); continue
      }
      try {
        $ext = [IO.Path]::GetExtension($abs).ToLower()
        $ct = $types[$ext]; if (-not $ct) { $ct = 'application/octet-stream' }
        $res.ContentType = $ct
        $fs = [IO.File]::OpenRead($abs)
        try {
          $res.ContentLength64 = $fs.Length
          $fs.CopyTo($res.OutputStream)
        } finally { $fs.Dispose() }
      } catch { try { $res.StatusCode = 500 } catch {} }
      $res.Close(); continue
    }

    # ---- Files browser: GET /open?path=<relpath> (open file/folder on the PC) ----
    if ($req.HttpMethod -eq 'GET' -and $path -eq '/open') {
      $abs = Resolve-HubPath $req.QueryString['path']
      if (-not $abs -or -not (Test-Path $abs)) {
        $res.StatusCode = 400
        $b = [Text.Encoding]::UTF8.GetBytes('{"opened":false,"error":"bad path"}')
        $res.ContentType = 'application/json'; $res.OutputStream.Write($b,0,$b.Length); $res.Close(); continue
      }
      # Refuse to launch anything outside the openable-extension whitelist.
      # Folders are always fine (Explorer); files must carry a safe extension so
      # /open can never Start-Process an executable/script (.exe .bat .ps1 ...).
      if (-not (Test-Path $abs -PathType Container)) {
        $ext = [IO.Path]::GetExtension($abs).ToLower()
        if (-not ($openableExts -contains $ext)) {
          $res.StatusCode = 403
          $b = [Text.Encoding]::UTF8.GetBytes('{"opened":false,"error":"extension not allowed"}')
          $res.ContentType = 'application/json'; $res.OutputStream.Write($b,0,$b.Length); $res.Close(); continue
        }
      }
      try {
        if (Test-Path $abs -PathType Container) {
          Start-Process explorer.exe -ArgumentList "`"$abs`""
        } else {
          Start-Process -FilePath $abs
        }
        $b = [Text.Encoding]::UTF8.GetBytes('{"opened":true}')
      } catch {
        $res.StatusCode = 500
        $b = [Text.Encoding]::UTF8.GetBytes('{"opened":false,"error":"open failed"}')
      }
      $res.ContentType = 'application/json'; $res.OutputStream.Write($b,0,$b.Length); $res.Close(); continue
    }

    # static file (OPEN, read-only). Containment-checked so a crafted path like
    # /..%2f..%2f cannot traverse out of the served Artifacts root: resolve the
    # full path and confirm it is the root or a child before serving.
    $rel = $path.TrimStart('/')
    if ([string]::IsNullOrWhiteSpace($rel)) { $rel = 'cowork-cockpit.html' }
    $file = $null
    try { $file = [IO.Path]::GetFullPath((Join-Path $root $rel)) } catch { $file = $null }
    $rootFullStatic = [IO.Path]::GetFullPath($root).TrimEnd('\')
    $insideRoot = $false
    if ($file) {
      if ($file.TrimEnd('\').Equals($rootFullStatic, [StringComparison]::OrdinalIgnoreCase)) { $insideRoot = $true }
      elseif ($file.StartsWith($rootFullStatic + '\', [StringComparison]::OrdinalIgnoreCase)) { $insideRoot = $true }
    }
    if (-not $insideRoot) { $res.StatusCode = 403; $res.Close(); continue }
    if (Test-Path $file -PathType Leaf) {
      $bytes = [IO.File]::ReadAllBytes($file)
      $ext = [IO.Path]::GetExtension($file).ToLower()
      $ct = $types[$ext]; if (-not $ct) { $ct = 'application/octet-stream' }
      $res.ContentType = $ct; $res.OutputStream.Write($bytes,0,$bytes.Length)
    } else { $res.StatusCode = 404 }
    $res.Close()
  } catch { try { $res.Close() } catch {} }
}
