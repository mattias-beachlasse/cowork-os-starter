# Cowork Cheat-Sheet — the magic words

New here? You don't need to learn commands or syntax. You just talk normally. But there are a handful of **phrases that trigger special powers** — say them and the system does something specific. Here's the whole set on one page.

---

## ⭐ The first five minutes
1. Just describe what you want in plain language — Cowork can read your files, draft things, search the web, and use your connected apps.
2. Say **"remember this: …"** to teach it a durable fact about you (it carries across chats).
3. Start a **new chat for each new task** — keeps things fast and focused.
4. When something matters, say **"loop it"** (below) to make the quality jump.
5. Stuck on what it can do? Ask: *"what can you help me with here?"*

---

## 🎯 Quality & rigor — make the output better
| Say this | What happens |
|---|---|
| **"loop it"** | Runs a quality loop: a *separate* checker scores the work against a rubric, sends fixes back, repeats, and reports a final score. Use it on anything important. |
| **"verify this"** | Forces a fact-check / double-check pass before trusting the answer. |
| **"deep dive"** | Thorough multi-source research with cross-checking, instead of a quick look. |
| **"MAX this one"** | Runs a single task at full rigor (verify-everything, multiple experts) without changing your normal setting. |

## 🧠 Capture & memory — keep the work off you
| Say this | What happens |
|---|---|
| **"remember this: …"** | Saves a durable fact to memory (preferences, people, context). |
| **"forget that"** | Removes a memory entry. |
| **"brain dump"** | It replies just **"Go."**, stays quiet while you offload everything on your mind, then turns it into a sorted, ranked task list. Great for a busy head. |
| (it will offer) | When you mention a commitment or a decision, it offers to log it to your tasks/decisions — just say yes. |

## 👥 Your AI team — talk to specialists by name
Address anyone by name and that "person" takes over. The starter team:
| Name | Role | Say something like |
|---|---|---|
| **Lisa** | Orchestrator (the default voice) | *"Lisa, plan my week."* She breaks the job down, delegates, checks the work, and reports back. |
| **Nolan** | Hiring | *"Nolan, I need an expert in X."* He defines the role and adds a new specialist to your team — this is how your team **grows to fit your life**. |
| **Pax** | Research | *"Pax, research the best X."* |
| **Ada** | Builder / tools & apps | *"Ada, build me a little tool that …"* |
*(Don't have a fitting expert? Ask Nolan to hire one.)*

## 🎨 Making things
| Say this | What happens |
|---|---|
| **"generate an image"** / "make a picture" | Creates images (set up your own image account in the skill first). |
| **"review board"** / "let me cull these" | Builds an interactive board to rate and pick from a batch of images. |
| **"scout the tools"** | Honest rundown of tool options (free/paid) for a new kind of project, then you pick. |

## ⚙️ Modes (if you're on the Pro-Lite setup)
One word in your `CLAUDE.md` sets how hard it works: **LEAN** (fast, light — the default), **STANDARD** (adds rigor where it counts), **MAX** (full power). Switch anytime, or just say **"MAX this one"** for a single task.

---

## 💡 Good habits
- **One task per chat.** Long chats get slower and the assistant starts losing track of earlier details — start fresh for a new task.
- **Say "loop it" on anything you'll send, publish, or rely on.**
- **Teach it as you go** with "remember this" — it gets more useful every week.
- **Let it do the clicking.** If a step can be done by the system, ask it to — don't do manual work it can handle.
- **In LEAN mode it won't auto-fact-check** — say "verify this" for anything important.

*Tip: you don't have to memorize this. Keep it handy for a week and the phrases you need will stick.*
