# DECISIONS

Real decisions worth looking up later — a direction, a tool pick, a "we're not doing Y." Newest on top. Not routine task detail.

## YYYY-MM-DD — example decision
What we decided and the one-line why.
