# MEMORY

Durable, reusable facts only — things worth looking up later. Not task detail (→ `TASKS.md`) or decisions (→ `DECISIONS.md`). Entries persist until you ask to change them. Flag contradictions; don't silently overwrite.

---

## ⭐ MEMORY-CORE  (the only part loaded at session start)

Keep this to about 6 lines — the facts Claude needs on *every* task. Everything below the line is lazy-loaded only when relevant.

- Name:
- Time zone / location:
- What I mainly use this hub for:
- How I like answers (length, tone):
- Key people / orgs Claude should know:
- Standing constraint(s):

---

## Full memory  (lazy-loaded — read only when the task touches it)

### People & relationships

### Preferences & working style

### Standing context

### Recurring constraints

---

*Tip: when Claude saves something durable it'll tell you in one line. Say "remember this" to force a save, or "forget that" to remove on