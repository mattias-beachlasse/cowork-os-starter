# PLAYBOOK

> **Lazy-loaded.** Claude reads this only when a task touches it — it is NOT part of session startup. Keep it that way; this is where operating know-how lives so the rulebook stays short.

Append dated heuristics as you learn what works. Format:

```
## YYYY-MM-DD — short title
TRIGGER: when this situation comes up…
ACTION: do this…
WHY: because…
```

Never delete heuristics, only refine. Consolidate periodically to stay lean.

---

## 2026-06-25 — Default to LEAN mode
TRIGGER: a new everyday task on Claude Pro.
ACTION: stay inline, no sub-agents, no extra rigor machinery.
WHY: sub-agent fan-out is the single biggest token cost; most tasks don't need it. Switch to STANDARD/MAX only when the task earns it.
