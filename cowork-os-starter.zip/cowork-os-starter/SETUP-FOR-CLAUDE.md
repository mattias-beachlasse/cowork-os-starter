# SETUP — read this and set me up

Hi Claude. This folder is a starter "Cowork OS" — a lean, no-skim hub. Help the user finish setting it up. Do what you can yourself; clearly flag the few steps only the user can do.

## What's here
- `CLAUDE.md` — the rulebook (thin, with a LEAN/STANDARD/MAX mode dial).
- `MEMORY.md` / `TASKS.md` / `DECISIONS.md` / `PLAYBOOK.md` / `Tools & Accounts.md` — blank templates.
- `Cowork Cheat-Sheet.md` — the magic words (loop it, brain dump, verify this, etc.).
- `AI Team/Roster.md` — the starter team (Lisa, Nolan, Pax, Ada). Ask Nolan to hire more.
- `skills/` — five skills to install (brain-dump, loop-it, image-gen, image-review, project-tool-scan).
- `Artifacts/` — the cockpit (a dashboard) + its local save server.
- `Tools/hub-index/` — a fast local search engine for the hub.
- `data-seed CSVs` (in Tasks/, *Database* folders) — empty data with the right columns.

## Steps
1. **[Claude] Interview the user** for the MEMORY-CORE block at the top of `CLAUDE.md` (name, what they do, how they like answers, key people, standing constraints). Fill it in.
2. **[User] Install the five skills:** open each `.skill` file in `skills/` and click "Save skill" (or Settings ▸ Capabilities). Per-machine; do it on each computer you use.
3. **[User] Connect your apps** (optional but recommended): Gmail/Calendar/Drive/etc. via Cowork's connectors. Claude can suggest which.
4. **[User] (optional) Run the cockpit:** double-click `Artifacts/Launch Cockpit (live save).bat` (Windows only — it's a PowerShell server). On Mac, skip the live server; the dashboard still opens read-only.
5. **[Claude] Customise:** rename/replace the example data folders (National Team, The Beach, etc.) with the user's own categories; the cockpit reads whatever you set up.
6. **[Claude] Tell them the magic words** from the cheat-sheet and offer a first task.

## The mode dial
`CLAUDE.md` has `MODE: LEAN`. LEAN = fast and light (great default). STANDARD = adds rigor. MAX = full power. They can switch the word anytime, or say "MAX this one" for a single task. In LEAN, Claude won't auto fact-check — say "verify this" when it matters.
