# START HERE — Pro-Lite Cowork Hub

A lean version of the Cowork OS, tuned to get **far more done inside Claude Pro's usage limit** while keeping nearly all the capability. Two-minute setup.

The idea in one line: **Pro gives you a rolling usage window, not a token meter — so the goal is lighter turns and fewer of them.** This kit keeps your context small, your sessions short, and your heavy work out of the main thread, so you burn through your limit much slower. You keep the power; you just spend the window better.

---

## Install (2 minutes)

1. Make a folder, e.g. `Cowork OS`.
2. Copy in: `CLAUDE.md`, `MEMORY.md`, `PLAYBOOK.md`, `TASKS.md`, `DECISIONS.md`, `Tools & Accounts.md`, and the `AI Team/` folder.
3. In the Claude desktop app, open **Cowork** and select that folder.
4. Open `MEMORY.md`, fill in the **MEMORY-CORE** block (about 6 lines), save. Done.

Claude reads `CLAUDE.md` automatically and follows it.

---

## The one dial that matters: MODE

Open `CLAUDE.md`. Near the top is one line — change the single word to switch how hard Claude works:

- **LEAN** *(default — start here)* — Claude does the task inline, but still sends a read-only search agent out for big lookups (so research stays fully powered without clogging your thread). Lightest on your usage. Great for ~90% of everyday work.
  - *One caveat:* in LEAN, Claude won't automatically fact-check or rate its confidence unless you ask. For anything you'll act on, add **"verify this"** or use STANDARD.
- **STANDARD** — adds light rigor where it pays (verification on important claims, a self-score, a quick idea/flaw-check on substantial tasks) and isolates heavy sub-tasks to keep your main thread lean. Moderate cost.
- **MAX** — the full multi-expert system: parallel sub-agents, verify-everything. Highest cost. For big, complex, high-stakes builds.

You don't have to commit — say **"do this one in MAX"** for a single task without changing your default. (And you can set any mode as your permanent default by editing that one word — e.g. `MODE: MAX` if a friend on a bigger plan wants full power all the time.)

**Which mode for what** (rough guide — you can ignore it and just leave it on LEAN):

| If the task is… | Use |
|---|---|
| Everyday drafting, summarizing, planning, quick lookups | **LEAN** |
| Something you'll send, publish, or rely on the facts of | **STANDARD** (or say "verify this") |
| A big, complex, high-stakes build where quality is everything | **MAX** (or "loop it") |

**You won't have to remember this.** The hub flags it for you: in STANDARD/MAX it tags answers with the mode it used (e.g. `[STANDARD]`); in LEAN it stays out of your way, but if a task touches money, health, legal, safety, or facts it's about to send, it adds a one-line offer to double-check or step up before handing it over. It'll also nudge you to start a fresh chat when one gets long.

---

## Why it stays cheap without going weak

Everything here reduces **how much gets re-billed each turn** and **how many turns you take** — the two things that actually move your Pro usage:

1. **Lazy-loading (biggest lever you control).** Instead of reading ~20k tokens of config at the start of every session, Claude loads files only when a task needs them — so every turn carries a smaller context.
2. **Short, stable rulebook.** The always-loaded `CLAUDE.md` is ~1,000 words (budget ≤1,800), not 5,000+ — lighter every turn, and a short rulebook is actually *followed* better.
3. **One task, one thread.** A long thread re-bills its whole history every turn; starting fresh per task is the fastest way to stretch your window. Claude auto-shortens very long chats on its own, but it does that *late* — so when a task wraps, just let Claude jot a 4–6 line handoff and start a fresh chat. **This is the single best habit to teach your friends.**
4. **Heavy work stays out of the main thread.** Verbose searches/lookups run in a separate read-only agent that hands back just a summary — so the noise never piles up in your billed context. (Bonus, handled automatically by the platform: stable files and read-only search agents are also cheaper under the hood — but that's the platform's do