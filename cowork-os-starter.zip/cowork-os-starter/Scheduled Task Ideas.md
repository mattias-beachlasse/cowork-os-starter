# Scheduled Task Ideas (templates)

Cowork can run tasks automatically on a schedule (say "every morning…", "each Monday…"). Here are common, useful ones — set any up by describing it (the `schedule` capability handles the rest). Replace the brackets.

## Daily
- **Morning digest** — "Every day at [07:00], summarise my unread email + today's calendar + my top 3 tasks."
- **News brief** — "Each morning, give me a short brief on [topics I care about]."

## Weekly
- **Weekly review** — "Every [Friday] afternoon, summarise what got done, what slipped, and rank next week's tasks."
- **Memory consolidation** — "Each [Sunday], tidy my memory/notes: merge duplicates, flag stale facts."
- **Capability radar** — "Weekly, surface one improvement to how I work — only if it's genuinely worth it."

## Event-driven / reminders
- **Prep-before-X** — "[N] days before each [meeting/event], prepare a short brief."
- **Birthdays/anniversaries** — "Remind me [3 days] before [person]'s birthday."
- **Follow-up chaser** — "If I haven't heard back on [thread] in [5 days], remind me."

## Maintenance
- **Search index refresh** — "Weekly, rebuild the hub search index."
- **Backup** — "Weekly, snapshot [important files]."

Tip: start with the morning digest and a weekly review — the two highest-value ones.
