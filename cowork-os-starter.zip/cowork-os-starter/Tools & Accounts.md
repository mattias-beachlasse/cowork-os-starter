# Tools & Accounts

> **Lazy-loaded** — read only when a task needs a specific tool or account.

Registry of the tools, connectors, and accounts this hub uses. Check here before proposing to add a new tool — you may already have one that does the job.

## Connectors / MCPs
- (e.g. Gmail, Calendar, Drive…) — what it's for

## Homegrown capabilities
- (scripts/skills you've built) — what they do

## Accounts
- (service — which login to use)
