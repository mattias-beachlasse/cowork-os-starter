# Hub Index — fast retrieval over the Cowork OS hub

A lightweight retrieval layer so an agent (Lisa) can find the right files and
passages in the hub by keyword/structure, instead of grepping blindly.

**Phase 1 = lexical + structural retrieval.** No embeddings. The whole text core
of the hub is only a few MB of language-rich prose, so SQLite **FTS5 + BM25** is
fast, accurate, and has zero model/runtime dependencies. Built with the Python
standard library only — nothing to `pip install`.

## What's here

| File | Role | Synced to Drive? |
|------|------|------------------|
| `build_index.py` | Walks the hub, writes the two artifacts below | yes (it's source) |
| `search.py` | Queries the index from code or the CLI; **self-heals** | yes (source) |
| `manifest.json` | One structural record per file (path, name, ext, size, modified, folder, title, headings) | **yes** — small, portable, human-readable |
| `index.db` | SQLite FTS5 full-text index (BM25-ranked) | **NO** — lives on LOCAL disk, never here (see below) |
| `.gitignore` | Keeps the db + temp/scratch out of sync/commits | yes |
| `README.md` | This file | yes |

## ⚠️ The one hard rule: `index.db` lives on LOCAL disk, NOT on Drive

SQLite needs real random-access file I/O (locking, seeking, `fsync`). Google
Drive's streamed/FUSE filesystem does **not** provide that. Building or opening
the db file *on the Drive mount* fails hard:

```
sqlite3.OperationalError: disk I/O error
```

This was independently reproduced and confirmed: the **identical** FTS5 build
fails on the Drive folder and succeeds on local disk. (Plain *text* writes to
Drive are fine — that's how `manifest.json` is written. Only SQLite's
random-access I/O breaks on Drive.)

So both scripts put `index.db` in a **per-OS local cache dir**, resolved by the
single shared function `build_index.db_path()`:

| OS | Default `index.db` location |
|----|------------------------------|
| **Windows** | `%LOCALAPPDATA%\CoworkOS\hub-index\index.db`  (e.g. `C:\Users\you\AppData\Local\CoworkOS\hub-index\index.db`) |
| **macOS / Linux** | `~/.cache/coworkos/hub-index/index.db` (respects `$XDG_CACHE_HOME`) |

Override with the env var **`COWORK_INDEX_DB`** (full path to the `.db` file);
the parent dir is auto-created. `build_index.py` and `search.py` resolve the
**same** path, so a build and a subsequent search always agree.

Because the db is machine-local, it's **portable across both laptops by
rebuilding**, not by syncing — each machine keeps its own copy in its own cache.
`manifest.json`, by contrast, IS meant to travel: it's a small, readable map of
the whole hub (titles + headings), usable even without the binary index, and it
doubles as the staleness signal for self-heal (below).

The `.gitignore` here keeps `index.db`, any temp db, and `*-journal`/`*.tmp`
scratch out of Drive sync and git — in case a stray copy ever lands in this
folder.

## Self-healing search (no manual build needed)

`search.py` **auto-builds the index** when it's missing or stale, so on a fresh
laptop you can just call `search("…")` and it works — no separate build step.

- **Missing** db → builds it.
- **Stale** db → rebuilds. "Stale" = `manifest.json` (which travels on Drive) is
  newer than the local `index.db`, i.e. the corpus moved on since this machine
  last built. Since the manifest syncs but the db doesn't, the first search on a
  laptop that pulled new hub content will refresh automatically.
- When it (re)builds, it prints a one-line `[search] index built/refreshed (…)`
  notice to **stderr**, so result output on stdout stays clean.

You can still build explicitly (below) — e.g. to warm the cache ahead of time.

## Auto-refresh at login (+ daily) — zero action needed

The index now refreshes itself with **no manual step**. `Setup\Refresh-Hub-Index.ps1`
rebuilds `index.db` + `manifest.json` and cleans up the Drive-side scratch files,
triggered two ways:

- **At every login** — `Artifacts\tasks-server.ps1` (the cockpit server, which
  already auto-starts via the Startup-folder `CoworkSession.vbs`) fires the
  refresh hidden and fire-and-forget at the top of its startup. Because that
  `.ps1` is launched **by absolute path** from the Startup launcher, editing it
  takes effect at the next login with **no re-run of any setup** — this is the
  zero-action path. The refresh is fully isolated in `try/catch` and runs in the
  background, so it can never delay or block the cockpit server's port bind.
- **Daily (06:40)** — a `schtasks` job, `"CoworkOS Daily Hub Index Refresh"`,
  registered by `Artifacts\Setup maintenance jobs.bat` (mirrors the daily-backup
  job). Belt-and-suspenders so a machine that stays logged in for days keeps a
  fresh index. This one only registers when that maintenance `.bat` is next run
  on a laptop; the login hook above needs nothing.

`Refresh-Hub-Index.ps1` is defensive by design: it finds Python robustly
(`py -3` → `python` → `python3`), and if none is found it writes one log line and
exits cleanly (never a popup, never a blocked session).

**Self-cleaning.** The refresh script also deletes the leftover scratch the Linux
sandbox couldn't remove from the Drive FUSE mount — in this folder only, and only
scratch patterns (`_probe.db*`, `_repro.db-journal`, `index.db.tmp*`,
`forced_on_drive.db.tmp*`, `__pycache__\`, stray `.fuse_hidden*` and any
`*.db`/`*.db-journal`/`*.tmp`). The real deliverables (`build_index.py`,
`search.py`, `README.md`, `.gitignore`, `manifest.json`) are never touched.

**Trail.** Each run appends one timestamped line to `last-refresh.log` in this
folder — `built OK` / `python-not-found` / `error …` — trimmed to the last ~20
lines so it stays tiny.

## How to rebuild (manual)

```bash
python3 "C:\CoworkOS\Tools\hub-index\build_index.py"
```

With no argument it indexes the hub root automatically: the script lives in
`Tools/hub-index/`, so the hub is two levels up, **validated by the presence of
`CLAUDE.md`** at that root (and it falls back to walking upward to find that
marker — so it doesn't matter whether the path is spelled `C:\CoworkOS\…` via
the junction or `…\My Drive\…`). To index a different root:

```bash
python3 build_index.py "C:\CoworkOS"
```

It's idempotent (drops + rebuilds fresh every run) and writes atomically: the db
builds to a `.tmp` **in the same local cache dir** then `os.replace()`s into
place (an in-filesystem, atomic rename — never a cross-fs move over the Drive
boundary); the manifest builds to a `.tmp` beside itself on Drive, `fsync`s, then
replaces. An interrupted run never leaves a half-written index or manifest.

## How to search

CLI:

```bash
python3 "C:\CoworkOS\Tools\hub-index\search.py" "verification standard"
python3 search.py "wild card eligibility" 5     # second arg = how many hits
```

From Python (e.g. inside an agent):

```python
from search import search
hits = search("Lisa supervisor loop", k=10)
# -> [{path, name, folder, score, excerpt}, ...]  (score higher = more relevant)
# auto-builds the index on first call if needed.
```

Each hit gives the relative `path`, the `folder`, a BM25 `score`, and a short
`excerpt` with the matched terms wrapped in `[brackets]` so you can see *why* it
matched.

## What gets indexed

- **Full text** (in `index.db`): every `.md`, `.txt`, `.csv`, `.html`, `.py`,
  `.js` file.
- **Structure only** (in `manifest.json`): every file, including binaries
  (`.png`, `.jpg`, `.blend`, `.mp4`, `.docx`, …) — these get a metadata record
  (path/name/ext/size/modified/folder) but no content.
- Markdown files contribute their `title` (first `#`) and all `#`/`##`/`###`
  headings to the manifest; CSVs contribute their header row.

**Skipped:** `.git`, `.svn`, `__pycache__`, `node_modules`, `venv`/`.venv`, the
`.tmp.drive*` sync-scratch dirs, and `Artifacts/downloads` (binary image dumps).
Machine-local db/journal/`.tmp` scratch files are skipped too, so a stray index
copy can't pollute the manifest. Embedded base64 data-URIs inside HTML are
stripped before indexing (they're search-noise, and left in they blew the index
up ~20x, ~315 MB → ~15 MB). Per-file body is capped at 1M chars as a backstop.

## The honest ceiling (and the upgrade path)

This is **lexical/structural** retrieval. It finds passages by the **words and
structure** actually present — keyword match, with BM25 ranking and stemming
(`porter`) so "payments"/"payment"/"paid" co-match. It is fast, transparent, and
needs no model.

What it does **not** do: find content by **paraphrased meaning**. A query for
"how do we keep the team honest" won't surface a passage titled "The Verification
Standard" unless they share words. For a keyword/structure hub like this one,
that's rarely a problem in practice — but it's the real limit.

**Upgrade path if/when semantic recall is needed:** add an embeddings layer as a
*hybrid* retriever — keep FTS5/BM25 for exact and structural matches, add a
vector index for meaning, and fuse the two rankings. That's a Phase-2 decision
to make only if real queries start missing on synonyms/paraphrase; it adds a
model dependency and index churn that Phase 1 deliberately avoids.

---
*Built and verified against the real hub on 2026-06-19. Phase-1 proof: 1,222
files full-text indexed, ~2.5s build, ~14.9 MB index (local), 739 KB manifest
(Drive). Drive-I/O bug fixed: db relocated to per-OS local cache, search
self-heals, builds atomically on local disk.*

---

## SB-v3 — Hybrid keyword + semantic search (optional add-on)

`semantic.py` adds a **meaning-based** retriever alongside the BM25 keyword index,
fused in `search.hybrid()` via **Reciprocal Rank Fusion** (the 2026 best practice).
It finds passages by meaning even with no shared words.

- **Embeddings:** `model2vec` static vectors (`minishlab/potion-retrieval-32M`, retrieval-tuned) —
  tiny, CPU-only, no torch/GPU. Vectors live on LOCAL disk next to `index.db`
  (never on Drive), rebuilt per machine.
- **One-time enable on a laptop:** `pip install model2vec` (the model ~30 MB
  auto-downloads once). Until then, `hybrid()` **falls back to keyword-only** —
  nothing breaks; it's a pure add-on.
- **Use:**
  ```
  python3 search.py "keeping the team honest" 5 --hybrid   # fused
  python3 semantic.py "a machine that never forgets" 5      # meaning-only
  python3 semantic.py --build                               # rebuild vectors
  ```
  Each hybrid hit is tagged `keyword` / `semantic` / `both` so you can see why it ranked.
- **From Python:** `from search import hybrid; hits, degraded = hybrid("...", k=10)`.
- **Chunked** (2026 best practice): each doc is split into ~700-char overlapping
  chunks with the header path prepended; query scores roll up to the best chunk per
  file, so long docs are found by the one matching passage.
- **Verified** 2026-06-20: 1,390 docs -> 12,873 chunks; hybrid hit-rate@5 = 6/6 on probe
  set; graceful keyword-only fallback confirmed. HONEST LIMIT: pure abstract paraphrase
  is still weak with static embeddings -- the *hybrid* is the reliable path, not
  semantic-alone; a cross-encoder reranker (future v6) is the fix.

## SB-v6/v7 — Reranking + eval harness (measured: rerank OFF by default)

`rerank.py` adds a cross-encoder (flashrank, ONNX/no-torch, ms-marco-MiniLM-L-12-v2)
and `search.best()` reranks the hybrid pool. `eval.py` + `eval/queries.tsv` (28 real
queries) measure hit-rate@5 / MRR@5.

**Measured 2026-06-20 on this hub:**
- keyword : hit@5 0.82, MRR 0.695
- hybrid  : hit@5 0.82, MRR 0.690
- best    : hit@5 ~0.80, MRR ~0.59  + ~2 s/query

VERDICT: on this keyword-rich hub the reranker does NOT help (it slightly hurts MRR
and adds latency), so **the default is keyword/hybrid; `best()` is opt-in** for cases
where it'd pay off (large, messy, paraphrase-heavy corpora). Re-run `python3 eval.py`
after content changes; if hybrid ever drops below ~0.80, that's the signal to revisit.
Requires `pip install flashrank` for best(); without it, best() falls back to hybrid order.
