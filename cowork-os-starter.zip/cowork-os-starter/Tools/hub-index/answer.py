#!/usr/bin/env python3
"""
answer.py — SB-v8 parent-child answer context.

Retrieval finds the right FILE (small chunks are best for that). But to ANSWER,
you want the surrounding SECTION, not a 700-char fragment. answer.context() takes
the top hits, opens each real file, locates the passage most relevant to the query,
and expands it to its enclosing markdown section (heading -> next heading) so Lisa
can quote whole, well-cited context.

  context(query, k=3) -> [{path, name, title, section, text}]

Reads the live files (current content), resolves the hub via build_index.
"""
import os, sys, re
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import build_index, search

CHUNK, OVERLAP, SEC_CAP = 700, 120, 2400


def _best_offset(text, query):
    terms = set(t.lower() for t in query.split() if len(t) > 2)
    if not terms:
        return 0
    best_off, best_score, i, n = 0, -1, 0, len(text)
    while i < n:
        low = text[i:i + CHUNK].lower()
        score = sum(low.count(t) for t in terms)
        if score > best_score:
            best_score, best_off = score, i
        i += CHUNK - OVERLAP
    return best_off


def _md_section(text, off):
    """Expand offset to the enclosing markdown section (preceding heading -> next heading)."""
    heads = [m.start() for m in re.finditer(r"(?m)^#{1,6}\s", text)]
    start = 0
    title = ""
    for h in heads:
        if h <= off:
            start = h
        else:
            break
    nxt = next((h for h in heads if h > start), len(text))
    seg = text[start:nxt].strip()
    first = seg.splitlines()[0] if seg else ""
    if first.startswith("#"):
        title = first.lstrip("# ").strip()
    return title, seg[:SEC_CAP]


def context(query, k=3):
    hub = build_index.resolve_hub_root(None)
    hits, _ = search.hybrid(query, k=k)
    out = []
    for h in hits:
        fp = os.path.join(hub, h["path"].replace("/", os.sep))
        try:
            text = open(fp, encoding="utf-8", errors="ignore").read()
        except OSError:
            text = ""
        off = _best_offset(text, query)
        if h["name"].lower().endswith((".md", ".txt")):
            title, seg = _md_section(text, off)
        else:
            seg = text[max(0, off - 100):off + SEC_CAP].strip()
            title = ""
        out.append({"path": h["path"], "name": h["name"],
                    "title": title or h["name"], "section": title,
                    "text": seg or h.get("excerpt", "")})
    return out


def _cli():
    args = [a for a in sys.argv[1:]]
    k = 3
    if len(args) >= 2 and args[-1].isdigit():
        k = int(args[-1]); args = args[:-1]
    q = " ".join(args)
    if not q:
        print('usage: python3 answer.py "question" [k]'); return
    for h in context(q, k):
        print("### %s  (%s)" % (h["title"], h["path"]))
        print(h["text"][:600].strip())
        print()


if __name__ == "__main__":
    _cli()
