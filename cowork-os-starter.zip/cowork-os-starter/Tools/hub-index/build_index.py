#!/usr/bin/env python3
"""
build_index.py — Cowork OS hub indexer (Phase 1: lexical + structural).

Walks the hub once and produces TWO artifacts:

  manifest.json   Human-readable, portable, SYNC-FRIENDLY. Lives BESIDE this
                  script (on Drive). One record per file:
                  {path, name, ext, size_bytes, modified, folder, title, headings[]}.
                  Markdown -> title (first #) + all #/##/### headings.
                  CSV      -> header row captured as headings.
                  Binaries -> metadata record only, no content.

  index.db        SQLite FTS5 full-text index of every .md/.txt/.csv/.html/.py/.js
                  file (table docs(path, name, folder, body)), BM25 ranking.
                  LOCAL-ONLY: lives in a per-OS local cache dir, NEVER on Drive.

WHY index.db is local-only (the bug this fixes)
  SQLite needs real random-access file I/O (locking, seeking, fsync). Google
  Drive's streamed/FUSE filesystem does NOT provide that: building/opening the db
  file *on the Drive mount* fails hard with `sqlite3.OperationalError: disk I/O
  error`. The identical build succeeds on local disk. So the db is built and
  opened on LOCAL disk only. (Plain text writes to Drive are fine -- that's how
  manifest.json is written -- only SQLite's random-access I/O breaks on Drive.)

  Default db location (override with env var COWORK_INDEX_DB):
    Windows : %LOCALAPPDATA%\\CoworkOS\\hub-index\\index.db
    mac/Linux: ~/.cache/coworkos/hub-index/index.db

Design notes
  - stdlib only (sqlite3 ships with FTS5 in Python 3.10+).
  - Atomic writes: build to <file>.tmp in the SAME dir, then os.replace().
    os.replace is atomic only within a filesystem, so the temp db sits in the
    LOCAL cache dir (never a cross-fs rename over the Drive boundary), and the
    temp manifest sits beside the final manifest on Drive.
  - Idempotent: each run builds a fresh index from scratch.
  - UTF-8 with errors='replace' so one bad byte can't crash the whole index.
  - Skips .git, .tmp.drive*, Artifacts/downloads, and common binary-heavy dirs.
  - Strips embedded base64 data-URIs before indexing (images/fonts pasted into
    HTML artifacts) -- pure search-noise that ballooned the index ~315 MB -> 15 MB.
    Per-file body is also capped.

Usage
  python3 build_index.py [HUB_ROOT]
  HUB_ROOT defaults to two levels up (this script lives in Tools/hub-index/,
  so ../../ is the hub root), validated by the presence of CLAUDE.md.
  Pass an explicit path to override.
"""
import os, sys, json, sqlite3, time, re

# Extensions whose full text we index in FTS5.
TEXT_EXTS = {".md", ".txt", ".csv", ".html", ".py", ".js"}
# Dir NAMES we never descend into (binary-heavy or machine-local scratch).
SKIP_DIRS = {".git", ".svn", "__pycache__", "node_modules", ".venv", "venv"}
# Path fragments (any segment) that mark skip zones.
SKIP_FRAGMENTS = (".tmp.drive",)
# Relative-path prefixes to skip (binary blob dumps). POSIX-style; matched
# against the normalized relative path.
SKIP_PREFIXES = ("Artifacts/downloads",)
# File SUFFIXES we never index/record: machine-local db + scratch artifacts.
# (The FTS db must live in the local cache, never on Drive; if a stray copy or
# a failed-on-Drive temp db lands in the tree, keep it out of the manifest.)
SKIP_FILE_SUFFIXES = (".db", ".db-journal", ".db-wal", ".db-shm",
                      ".db.tmp", "-journal", ".tmp")
# Cap indexed body per file (chars). Real prose files are far under this;
# the cap only bites pathological machine-generated files.
MAX_BODY_CHARS = 1_000_000
# Strips embedded base64 data-URIs (images/fonts) -- pure noise for search,
# and the single biggest source of index bloat in HTML artifacts.
DATA_URI_RE = re.compile(r"data:[^;,\s]+;base64,[A-Za-z0-9+/=]+")

HERE = os.path.dirname(os.path.abspath(__file__))


def db_path():
    """
    Resolve the LOCAL (never-Drive) path for index.db, shared by build + search.

    Priority:
      1. $COWORK_INDEX_DB (explicit override; full path to the .db file)
      2. Windows : %LOCALAPPDATA%\\CoworkOS\\hub-index\\index.db
                   (fallback %USERPROFILE%\\AppData\\Local\\... if LOCALAPPDATA
                    is somehow unset)
      3. mac/Linux: $XDG_CACHE_HOME/coworkos/hub-index/index.db
                    else ~/.cache/coworkos/hub-index/index.db
    The parent dir is created if missing.
    """
    override = os.environ.get("COWORK_INDEX_DB")
    if override:
        p = os.path.abspath(os.path.expandvars(os.path.expanduser(override)))
    elif os.name == "nt":
        base = os.environ.get("LOCALAPPDATA")
        if not base:
            base = os.path.join(
                os.environ.get("USERPROFILE", os.path.expanduser("~")),
                "AppData", "Local")
        p = os.path.join(base, "CoworkOS", "hub-index", "index.db")
    else:
        base = os.environ.get("XDG_CACHE_HOME") or os.path.join(
            os.path.expanduser("~"), ".cache")
        p = os.path.join(base, "coworkos", "hub-index", "index.db")
    os.makedirs(os.path.dirname(p), exist_ok=True)
    return p


def resolve_hub_root(explicit=None):
    """
    Robustly resolve the hub root. Prefer an explicit arg; otherwise two levels
    up from this script. Validate by the presence of CLAUDE.md. Works regardless
    of the C:\\CoworkOS junction vs 'My Drive' path spelling, because it resolves
    relative to THIS script's real location, never a hardcoded path.
    """
    if explicit:
        root = os.path.abspath(explicit)
    else:
        root = os.path.abspath(os.path.join(HERE, "..", ".."))
    marker = os.path.join(root, "CLAUDE.md")
    if not os.path.exists(marker):
        cur = HERE
        for _ in range(6):
            cur = os.path.dirname(cur)
            if os.path.exists(os.path.join(cur, "CLAUDE.md")):
                return cur
        sys.stderr.write(
            f"WARNING: no CLAUDE.md found at hub root '{root}'. "
            f"Indexing it anyway -- pass an explicit HUB_ROOT if this is wrong.\n")
    return root


def should_skip_dir(dirname):
    if dirname in SKIP_DIRS:
        return True
    for frag in SKIP_FRAGMENTS:
        if frag in dirname:
            return True
    return False


def should_skip_relpath(rel):
    rel_posix = rel.replace(os.sep, "/")
    for pref in SKIP_PREFIXES:
        if rel_posix == pref or rel_posix.startswith(pref + "/"):
            return True
    for frag in SKIP_FRAGMENTS:
        if frag in rel_posix:
            return True
    return False


def read_text(path):
    """Read a text file robustly; never raise on encoding."""
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return f.read()
    except (OSError, IOError):
        return ""


def extract_md(text):
    """Return (title, headings[]) from markdown # / ## / ### lines."""
    title = ""
    headings = []
    for line in text.splitlines():
        s = line.strip()
        if s.startswith("#"):
            n = len(s) - len(s.lstrip("#"))
            if 1 <= n <= 3 and (len(s) == n or s[n] == " "):
                htext = s[n:].strip()
                if htext:
                    headings.append(htext)
                    if n == 1 and not title:
                        title = htext
    if not title and headings:
        title = headings[0]
    return title, headings


def extract_csv_header(text):
    """First non-empty line's comma-split fields as headings."""
    for line in text.splitlines():
        if line.strip():
            return [c.strip() for c in line.split(",") if c.strip()]
    return []


def walk_hub(hub_root):
    """Single pass over the hub. Returns (manifest, fts_rows, counts)."""
    manifest = []
    fts_rows = []  # (path, name, folder, body)
    counts = {"total": 0, "indexed_text": 0, "binary": 0, "skipped": 0}

    for dirpath, dirnames, filenames in os.walk(hub_root):
        rel_dir = os.path.relpath(dirpath, hub_root)
        if rel_dir == ".":
            rel_dir = ""
        dirnames[:] = [
            d for d in dirnames
            if not should_skip_dir(d)
            and not should_skip_relpath(os.path.join(rel_dir, d) if rel_dir else d)
        ]

        for fn in filenames:
            rel = os.path.join(rel_dir, fn) if rel_dir else fn
            if should_skip_relpath(rel):
                counts["skipped"] += 1
                continue
            if fn.endswith(SKIP_FILE_SUFFIXES):
                counts["skipped"] += 1
                continue
            full = os.path.join(dirpath, fn)
            try:
                st = os.stat(full)
            except OSError:
                counts["skipped"] += 1
                continue

            ext = os.path.splitext(fn)[1].lower()
            folder = rel_dir.replace(os.sep, "/")
            rel_posix = rel.replace(os.sep, "/")
            counts["total"] += 1

            rec = {
                "path": rel_posix,
                "name": fn,
                "ext": ext,
                "size_bytes": st.st_size,
                "modified": time.strftime("%Y-%m-%dT%H:%M:%S",
                                          time.localtime(st.st_mtime)),
                "folder": folder,
                "title": "",
                "headings": [],
            }

            if ext in TEXT_EXTS:
                text = read_text(full)
                if "base64," in text:
                    text = DATA_URI_RE.sub("[data-uri]", text)
                if len(text) > MAX_BODY_CHARS:
                    text = text[:MAX_BODY_CHARS]
                if ext == ".md":
                    rec["title"], rec["headings"] = extract_md(text)
                elif ext == ".csv":
                    rec["headings"] = extract_csv_header(text)
                if not rec["title"]:
                    rec["title"] = os.path.splitext(fn)[0]
                fts_rows.append((rel_posix, fn, folder, text))
                counts["indexed_text"] += 1
            else:
                rec["title"] = os.path.splitext(fn)[0]
                counts["binary"] += 1

            manifest.append(rec)

    manifest.sort(key=lambda r: r["path"].lower())
    return manifest, fts_rows, counts


def write_manifest(hub_root, manifest, counts):
    """Atomic write of manifest.json beside this script (on Drive -- text is OK)."""
    man_path = os.path.join(HERE, "manifest.json")
    man_tmp = man_path + ".tmp"
    payload = {
        "hub_root_indexed": hub_root,
        "built": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "counts": counts,
        "files": manifest,
    }
    with open(man_tmp, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=1)
        f.flush()
        os.fsync(f.fileno())
    os.replace(man_tmp, man_path)
    return man_path, os.path.getsize(man_path)


def write_index_db(fts_rows):
    """
    Atomic build of index.db on LOCAL disk. Temp db sits in the SAME local dir
    as the final db so os.replace() is an in-filesystem (atomic) rename -- never
    a cross-fs move over the Drive boundary.
    """
    final = db_path()
    tmp = final + ".tmp"
    for stale in (tmp, tmp + "-journal"):
        try:
            os.remove(stale)
        except OSError:
            pass
    con = sqlite3.connect(tmp)
    try:
        con.execute(
            "CREATE VIRTUAL TABLE docs USING fts5("
            "path, name, folder, body, tokenize='porter unicode61')")
        con.executemany(
            "INSERT INTO docs(path, name, folder, body) VALUES (?,?,?,?)",
            fts_rows)
        con.commit()
        con.execute("INSERT INTO docs(docs) VALUES('optimize')")
        con.commit()
    finally:
        con.close()
    os.replace(tmp, final)
    return final, os.path.getsize(final)


def build(hub_root):
    hub_root = resolve_hub_root(hub_root)
    t0 = time.time()
    manifest, fts_rows, counts = walk_hub(hub_root)
    man_path, man_size = write_manifest(hub_root, manifest, counts)
    db_file, db_size = write_index_db(fts_rows)
    dt = time.time() - t0

    print(f"Indexed hub: {hub_root}")
    print(f"  files seen (kept):     {counts['total']}")
    print(f"  full-text indexed:     {counts['indexed_text']}")
    print(f"  binary (meta only):    {counts['binary']}")
    print(f"  skipped (skip-zones):  {counts['skipped']}")
    print(f"  manifest.json:         {man_size/1024:.1f} KB  (Drive)  -> {man_path}")
    print(f"  index.db (FTS5):       {db_size/1024:.1f} KB  (LOCAL)  -> {db_file}")
    print(f"  build time:            {dt:.2f}s")
    return counts


if __name__ == "__main__":
    root = sys.argv[1] if len(sys.argv) > 1 else None
    build(root)
