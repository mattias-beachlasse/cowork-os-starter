#!/usr/bin/env python3
"""eval.py — SB-v7: measure retrieval quality on a fixed query set.
Reports hit-rate@5 and MRR@5 for keyword / hybrid / best(reranked).
Usage: python3 eval.py [k]   (default k=5).  Web bar: hit-rate@5 >= 0.80."""
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import search

def load():
    p = os.path.join(HERE, "eval", "queries.tsv")
    out = []
    for line in open(p, encoding="utf-8"):
        line = line.rstrip("\n")
        if not line or "\t" not in line:
            continue
        q, exp = line.split("\t", 1)
        out.append((q.strip(), exp.strip().lower()))
    return out

def rank_of(hits, exp):
    for i, h in enumerate(hits, 1):
        hay = ((h.get("folder") or "") + "/" + (h.get("name") or "")).lower()
        if exp in hay:
            return i
    return 0

def run(name, fn, qs, k):
    hit = mrr = 0
    misses = []
    for q, exp in qs:
        hits = fn(q, k)
        r = rank_of(hits, exp)
        if r:
            hit += 1; mrr += 1.0 / r
        else:
            misses.append(q)
    n = len(qs)
    print("%-9s hit@%d=%.2f (%d/%d)   MRR@%d=%.3f" % (name, k, hit/n, hit, n, k, mrr/n))
    return misses

def main():
    k = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else 5
    qs = load()
    print("eval set: %d queries, k=%d\n" % (len(qs), k))
    run("keyword", lambda q, k: search.search(q, k), qs, k)
    run("hybrid",  lambda q, k: search.hybrid(q, k)[0], qs, k)
    m = run("best",    lambda q, k: search.best(q, k)[0], qs, k)
    if m:
        print("\nbest() misses:", "; ".join(m))

if __name__ == "__main__":
    main()
