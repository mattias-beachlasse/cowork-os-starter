#!/usr/bin/env python3
"""
rerank.py — SB-v6 cross-encoder reranking (optional, lightweight, graceful).

A bi-encoder (semantic.py) is fast but coarse: it scores query and passage
SEPARATELY. A cross-encoder reads (query, passage) TOGETHER and is far sharper on
precision -- the documented fix for the abstract-paraphrase weakness the v1-v5
tests exposed. We run it only over the ~20 candidates from hybrid retrieval, so it
stays cheap at query time.

Backend: `flashrank` (ONNX, NO torch/GPU) with ms-marco-MiniLM-L-12-v2 (~34 MB,
auto-downloads once). If flashrank isn't installed, rerank() returns the input
order unchanged and reports unavailable -- pure add-on, never breaks search.

One-time per machine:  pip install flashrank
"""
import os

_ranker = None
MODEL = "ms-marco-MiniLM-L-12-v2"


class RerankUnavailable(RuntimeError):
    pass


def _get_ranker():
    global _ranker
    if _ranker is None:
        try:
            from flashrank import Ranker
        except Exception as e:
            raise RerankUnavailable("flashrank not installed -- `pip install flashrank`") from e
        _ranker = Ranker(model_name=MODEL, max_length=512)
    return _ranker


def available():
    try:
        _get_ranker(); return True
    except RerankUnavailable:
        return False


def rerank(query, candidates):
    """
    candidates: [{path, name, folder, text, ...}]  (text = representative passage)
    returns: (reranked_list, ok)  -- each item gets 'rerank_score'; ok=False if the
    reranker is unavailable (list returned unchanged).
    """
    if not candidates:
        return candidates, True
    try:
        ranker = _get_ranker()
        from flashrank import RerankRequest
    except RerankUnavailable:
        return candidates, False
    passages = [{"id": i, "text": (c.get("text") or c.get("name", ""))[:2000], "meta": c}
                for i, c in enumerate(candidates)]
    out = ranker.rerank(RerankRequest(query=query, passages=passages))
    ranked = []
    for o in out:
        c = dict(o["meta"])
        c["rerank_score"] = round(float(o["score"]), 4)
        ranked.append(c)
    return ranked, True


if __name__ == "__main__":
    print("flashrank available:", available())
