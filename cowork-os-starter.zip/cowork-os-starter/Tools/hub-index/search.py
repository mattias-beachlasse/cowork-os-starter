#!/usr/bin/env python3
"""
search.py — query the Cowork OS hub index (self-healing).

  search(query, k=10)  -> [{path,name,folder,score,excerpt}]                 keyword/BM25
  hybrid(query, k=10)  -> ([{path,name,folder,score,found_by,excerpt}], degraded)
                          keyword + semantic, fused by Reciprocal Rank Fusion (SB-v3)
  best(query, k=10)    -> ([{...,rerank_score,passage}], info)
                          hybrid pool -> cross-encoder rerank (SB-v6); best quality

Degrades gracefully at every tier: no model2vec -> hybrid is keyword-only; no
flashrank -> best() falls back to hybrid order. The db lives on LOCAL disk.

CLI:
  python3 search.py "verification standard"
  python3 search.py "keeping the team honest" 5 --hybrid
  python3 search.py "keeping the team honest" 5 --best
"""
import os, sys, sqlite3

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
import build_index

MANIFEST_PATH = os.path.join(HERE, "manifest.json")
_CHUNK, _OVERLAP = 700, 120


def _db_path():
    return build_index.db_path()


def _needs_build(db_path):
    if not os.path.exists(db_path):
        return True, "missing"
    try:
        db_m = os.path.getmtime(db_path)
    except OSError:
        return True, "unreadable"
    if os.path.exists(MANIFEST_PATH):
        try:
            if os.path.getmtime(MANIFEST_PATH) > db_m:
                return True, "stale (manifest newer than index)"
        except OSError:
            pass
    return False, ""


def _ensure_index(db_path):
    need, why = _needs_build(db_path)
    if need:
        build_index.build(None)
        sys.stderr.write("[search] index built/refreshed (%s).\n" % why)


def _fts_query(raw):
    terms = [t for t in raw.replace('"', " ").split() if t]
    if not terms:
        return '""'
    return " OR ".join('"' + t + '"' for t in terms)


def search(query, k=10, db_path=None):
    if db_path is None:
        db_path = _db_path()
    _ensure_index(db_path)
    con = sqlite3.connect(db_path)
    try:
        match = _fts_query(query)
        rows = con.execute(
            "SELECT path, name, folder, bm25(docs) AS score, "
            "snippet(docs, 3, '[', ']', ' ... ', 12) AS excerpt "
            "FROM docs WHERE docs MATCH ? ORDER BY bm25(docs) LIMIT ?",
            (match, k),
        ).fetchall()
    finally:
        con.close()
    out = []
    for path, name, folder, score, excerpt in rows:
        out.append({"path": path, "name": name, "folder": folder,
                    "score": round(-score, 3), "excerpt": " ".join((excerpt or "").split())})
    return out


def hybrid(query, k=10, rrf_k=60):
    """Fuse keyword (BM25) + semantic (vector) via Reciprocal Rank Fusion.
    Returns (hits, degraded); found_by in {keyword, semantic, both}."""
    kw = search(query, k=max(k * 3, 20))
    fused = {}
    for rank, h in enumerate(kw, 1):
        e = fused.setdefault(h["path"], dict(h, rrf=0.0, found_by=set()))
        e["rrf"] += 1.0 / (rrf_k + rank)
        e["found_by"].add("keyword")
    degraded = False
    try:
        import semantic
        for h in semantic.semantic_search(query, k=max(k * 3, 20)):
            e = fused.get(h["path"])
            if e is None:
                e = fused[h["path"]] = {"path": h["path"], "name": h["name"],
                                        "folder": h["folder"], "excerpt": "",
                                        "rrf": 0.0, "found_by": set()}
            e["rrf"] += 1.0 / (rrf_k + h["rank"])
            e["found_by"].add("semantic")
    except Exception as exc:
        sys.stderr.write("[hybrid] semantic layer off (%s); keyword-only.\n" % exc.__class__.__name__)
        degraded = True
    ranked = sorted(fused.values(), key=lambda x: -x["rrf"])[:k]
    out = []
    for h in ranked:
        fb = h["found_by"]
        out.append({"path": h["path"], "name": h["name"], "folder": h["folder"],
                    "score": round(h["rrf"], 5),
                    "found_by": "both" if len(fb) == 2 else next(iter(fb)),
                    "excerpt": h.get("excerpt", "")})
    return out, degraded


def _bodies(paths, db_path=None):
    if not paths:
        return {}
    if db_path is None:
        db_path = _db_path()
    con = sqlite3.connect(db_path)
    try:
        q = "SELECT path, body FROM docs WHERE path IN (%s)" % ",".join("?" * len(paths))
        rows = con.execute(q, list(paths)).fetchall()
    finally:
        con.close()
    return {p: (b or "") for p, b in rows}


def _passage_for(body, query, cap=20000):
    """Pick the ~700-char window of body with the most query-term overlap (cheap, no model)."""
    body = (body or "")[:cap]
    if not body.strip():
        return ""
    terms = set(t.lower() for t in query.split() if len(t) > 2)
    best_txt, best_score, i, n = body[:_CHUNK], -1, 0, len(body)
    while i < n:
        piece = body[i:i + _CHUNK]
        low = piece.lower()
        score = sum(low.count(t) for t in terms)
        if score > best_score:
            best_score, best_txt = score, piece
        i += _CHUNK - _OVERLAP
    return best_txt.strip()


def best(query, k=10, pool=24):
    """SB-v6: hybrid pool -> cross-encoder rerank. Returns (hits, info).
    info = {degraded(bool, semantic off), reranked(bool, reranker ran)}."""
    cand, degraded = hybrid(query, k=pool)
    bodies = _bodies([c["path"] for c in cand])
    for c in cand:
        c["passage"] = _passage_for(bodies.get(c["path"], ""), query)
        c["text"] = c["passage"] or c["excerpt"] or c["name"]
    try:
        import rerank
        reranked, ok = rerank.rerank(query, cand)
    except Exception as exc:
        sys.stderr.write("[best] rerank off (%s); hybrid order.\n" % exc.__class__.__name__)
        reranked, ok = cand, False
    hits = []
    for h in reranked[:k]:
        hits.append({"path": h["path"], "name": h["name"], "folder": h["folder"],
                     "found_by": h.get("found_by", "?"),
                     "rerank_score": h.get("rerank_score"),
                     "passage": (h.get("passage") or "")[:300]})
    return hits, {"degraded": degraded, "reranked": ok}


def _print(query, hits, tag):
    if not hits:
        print("No results for: %r" % query); return
    print("Query: %r  (%d hits)%s\n" % (query, len(hits), tag))
    for i, h in enumerate(hits, 1):
        loc = h["folder"] + "/" if h["folder"] else ""
        extra = ""
        if h.get("rerank_score") is not None:
            extra = " rr=%s" % h["rerank_score"]
        elif "score" in h:
            extra = " [%s]" % h["score"]
        fb = " (%s)" % h["found_by"] if h.get("found_by") and h["found_by"] != "?" else ""
        print("%d.%s%s %s%s" % (i, extra, fb, loc, h["name"]))
        print("   " + h["path"])
        snip = h.get("passage") or h.get("excerpt") or ""
        if snip:
            print("   ..." + " ".join(snip.split())[:200] + "...")
        print()


def _cli():
    args = sys.argv[1:]
    if not args:
        print('usage: python3 search.py "query" [k] [--hybrid|--best]'); sys.exit(1)
    mode = "keyword"
    if "--best" in args: mode = "best"
    if "--hybrid" in args: mode = "hybrid"
    args = [a for a in args if a not in ("--hybrid", "--best")]
    k = 10
    if len(args) >= 2 and args[-1].isdigit():
        k = int(args[-1]); args = args[:-1]
    query = " ".join(args)
    if mode == "best":
        hits, info = best(query, k)
        tag = " (reranked)" if info["reranked"] else " (rerank off -> hybrid order)"
        _print(query, hits, tag)
    elif mode == "hybrid":
        hits, degraded = hybrid(query, k)
        _print(query, hits, " (keyword-only fallback)" if degraded else " (keyword+semantic)")
    else:
        _print(query, search(query, k), "")


if __name__ == "__main__":
    _cli()
