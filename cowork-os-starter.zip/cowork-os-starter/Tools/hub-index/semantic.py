#!/usr/bin/env python3
"""
semantic.py — optional MEANING-based retrieval over the hub (SB-v3, chunked).

The vector half of the hybrid retriever (fused with BM25 in search.hybrid via RRF).
Finds passages by meaning even when they share no words with the query.

WHY CHUNKED (2026 RAG best practice): a single vector per whole document is "mush"
for long docs and loses anything past a truncation cap. So we split each document
into small overlapping chunks, PREPEND the header path (name + folder) to each
chunk's text (one of the highest-ROI retrieval tweaks), embed every chunk, then at
query time score chunks and roll up to the best-scoring chunk per file. Result:
a long roadmap is found by the one paragraph that matches, not its first 4000 chars.

DESIGN — local-first, graceful, zero-config-degrading:
  - Embeddings via `model2vec` StaticModel (potion-base-8M, 256-dim): tiny, CPU-only.
    One-time per machine:  pip install model2vec   (model ~30 MB auto-downloads once)
  - If model2vec/numpy aren't installed, every entry point raises SemanticUnavailable;
    search.hybrid() catches it and falls back to keyword-only. Pure add-on.
  - Vectors live on LOCAL disk next to index.db (never on Drive), rebuilt per machine.
  - Reads the SAME documents as the keyword index (docs table in index.db).

CLI:
  python3 semantic.py --build
  python3 semantic.py "keeping the team honest" 5
"""
import os, sys, json, sqlite3

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
import build_index

MODEL_NAME = "minishlab/potion-retrieval-32M"
DOC_CAP    = 20000   # max chars of body considered per doc (backstop vs huge CSV notes)
CHUNK      = 700     # chars per chunk
OVERLAP    = 120     # chars of overlap between chunks
MAX_CHUNKS = 40      # cap chunks per doc so one giant doc can't dominate
_model = None


class SemanticUnavailable(RuntimeError):
    """Raised when model2vec/numpy aren't installed; callers fall back to BM25."""


def _vec_dir():
    d = os.path.dirname(build_index.db_path())
    os.makedirs(d, exist_ok=True)
    return d


def _vec_paths():
    d = _vec_dir()
    return os.path.join(d, "vectors.npy"), os.path.join(d, "vectors_meta.json")


def _get_model():
    global _model
    if _model is None:
        try:
            from model2vec import StaticModel
        except Exception as e:
            raise SemanticUnavailable(
                "model2vec not installed -- run `pip install model2vec` to enable "
                "semantic search; keyword search works without it."
            ) from e
        _model = StaticModel.from_pretrained(MODEL_NAME)
    return _model


def _np():
    try:
        import numpy as np
        return np
    except Exception as e:
        raise SemanticUnavailable("numpy not installed.") from e


def _chunks(text):
    text = (text or "")[:DOC_CAP]
    if not text.strip():
        return []
    out, i, n = [], 0, len(text)
    while i < n and len(out) < MAX_CHUNKS:
        piece = text[i:i + CHUNK].strip()
        if piece:
            out.append(piece)
        i += CHUNK - OVERLAP
    return out


def build(db_path=None):
    """Chunk every document, embed chunks (header-path prepended), store vectors locally."""
    np = _np()
    model = _get_model()
    if db_path is None:
        db_path = build_index.db_path()
    if not os.path.exists(db_path):
        build_index.build(None)
    con = sqlite3.connect(db_path)
    try:
        rows = con.execute("SELECT path, name, folder, body FROM docs").fetchall()
    finally:
        con.close()

    meta, texts = [], []
    for path, name, folder, body in rows:
        header = f"{name} | {folder} | "          # header-path prepend (high ROI)
        cs = _chunks(body) or [""]
        for c in cs:
            meta.append({"path": path, "name": name, "folder": folder})
            texts.append(header + c)

    vecs = np.asarray(model.encode(texts), dtype="float32")
    norms = np.linalg.norm(vecs, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    vecs = vecs / norms

    vpath, mpath = _vec_paths()
    np.save(vpath, vecs)
    with open(mpath, "w", encoding="utf-8") as f:
        json.dump(meta, f)
    return len(rows), len(meta)


def _ensure_built():
    vpath, mpath = _vec_paths()
    db = build_index.db_path()
    fresh = (os.path.exists(vpath) and os.path.exists(mpath) and os.path.exists(db)
             and os.path.getmtime(vpath) >= os.path.getmtime(db))
    if not fresh:
        ndoc, nch = build(db)
        sys.stderr.write(f"[semantic] vector index built ({ndoc} docs, {nch} chunks).\n")


def semantic_search(query, k=10):
    """Return [{path,name,folder,score,rank}] — best-chunk score rolled up per file."""
    np = _np()
    model = _get_model()
    _ensure_built()
    vpath, mpath = _vec_paths()
    try:
        vecs = np.load(vpath)
        with open(mpath, encoding="utf-8") as f:
            meta = json.load(f)
    except Exception:                      # corrupt/partial vectors -> rebuild once
        build(build_index.db_path())
        vecs = np.load(vpath)
        with open(mpath, encoding="utf-8") as f:
            meta = json.load(f)
    q = np.asarray(model.encode([query]), dtype="float32")[0]
    q = q / (np.linalg.norm(q) or 1.0)
    sims = vecs @ q
    # roll chunk scores up to the best score per file path
    best = {}
    order = np.argsort(-sims)
    for i in order[:max(k * 30, 300)]:
        m = meta[int(i)]
        p = m["path"]
        s = float(sims[int(i)])
        if p not in best or s > best[p]["score"]:
            best[p] = {"path": p, "name": m["name"], "folder": m["folder"], "score": round(s, 4)}
    ranked = sorted(best.values(), key=lambda x: -x["score"])[:k]
    for r, h in enumerate(ranked, 1):
        h["rank"] = r
    return ranked


def _cli():
    args = sys.argv[1:]
    if args and args[0] == "--build":
        ndoc, nch = build()
        print(f"vector index built: {ndoc} docs, {nch} chunks")
        return
    if not args:
        print('usage: python3 semantic.py "query" [k]   |   python3 semantic.py --build')
        return
    k = 10
    if len(args) >= 2 and args[-1].isdigit():
        k = int(args[-1]); args = args[:-1]
    try:
        hits = semantic_search(" ".join(args), k)
    except SemanticUnavailable as e:
        print(f"semantic unavailable: {e}"); return
    for h in hits:
        loc = (h["folder"] + "/") if h["folder"] else ""
        print(f'{h["rank"]:>2}. [{h["score"]}] {loc}{h["name"]}')


if __name__ == "__main__":
    _cli()
