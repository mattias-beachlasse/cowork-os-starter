---
name: brain-dump
description: Capture a free-form brain dump from you and turn it into tracked tasks. Use when you say "brain dump", "let me dump", "brain dump on X", or otherwise signals he wants to offload everything on your mind at once. The skill makes Claude reply only "Go.", stay silent while he talks, then extract every commitment into the right TASKS.md, flag memory items, offer to draft comms, and end with a ranked task list.
---

# Brain dump

When you say **"brain dump"** (or a clear variation), reply only **"Go."** — nothing else. Stay silent while he talks; do not interrupt, summarize, or react between his messages.

When he signals he's finished ("done", "that's it", "finished", or similar):

1. **Extract every commitment, follow-up, and pending item** into the right subfolder `TASKS.md` (smart-default the project; one-tap confirm where non-obvious).
2. **Flag anything durable for permanent memory** and ask once: *"Anything here you want saved to memory?"*
3. **Offer to draft any needed communications** (emails, messages) that came up.
4. **End with the ranked task list** — full list ranked (overdue → hard deadlines → blocking others → relationship stakes), #1 = recommended start; you pick.

Keep the work off you: capture proactively, confirm in one line, respect a "no."
