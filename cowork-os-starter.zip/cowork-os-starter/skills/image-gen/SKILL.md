---
name: image-gen
description: Generate images (or video) on request. Use when you say "generate an image", "make a picture", "make a video", "render this", "create a visual", or similar. Drives your chosen image-generation tool to produce, name, and save images, with consistency rules for a matched set.
---

# Image generation

Generate images/video on request using your chosen image tool (set up your own account/tool first — fill in the specifics below for your setup).

- **Pick the tool once** and note it here: which service/account, how it's driven (browser tab, API, app), and where downloads land. Replace this line with your details.
- **Images vs video:** images are usually cheap/unlimited; video is scarce — reserve it for hero moments, and get the best result by animating from a strong still (image-to-video).
- **If a request is declined,** resend the same prompt once; repeated declines usually mean a temporary cap — pause and say so.
- **Naming:** after a batch downloads, rename each to something descriptive (`<subject>-<detail>-NN.png`) so nothing generic is left lying around.
- **Consistency across a set:** make one "style anchor" image first, then attach it as a reference on every later generation.

For culling a batch afterwards, use the **image-review** skill.
