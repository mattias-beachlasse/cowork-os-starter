---
name: image-review
description: Build an interactive Image Review Board so you can cull a batch of generated images. Use after generating images, or when you say "review board", "let me cull these", "let me pick", or wants to sort/rate a set of images. Generates a self-contained HTML board (grid + cull mode, love/almost/no keys, notes, filters, copy-picks) from the Gemini thread, so you rates and pastes your picks back.
---

# Image review loop

Generate the batch in **ONE Gemini thread** (consistent style). Then build the Review Board:

- Run the Chrome-ext `javascript_tool` on the thread: `blob:` image URLs are same-origin → draw to canvas → export inline JPEG dataURLs → assemble one self-contained **`Image Review Board.html`**, blob-downloaded to `Artifacts/downloads/`.
- **Board features:** Grid + Cull mode (keys `1`=Love, `2`=Almost, `3`=No, auto-advance; `←`/`→` to move; `G`/`C` to switch views) + per-image note + filters + counts + a **"Copy my picks"** button.
- you cull, notes the Almosts, hits Copy and pastes back (your picks live in your browser; the assistant can not read them directly).
- Lisa then **keeps the Loves, iterates the Almosts per his notes, discards the Nos.**

Full method also in `PLAYBOOK.md`.
