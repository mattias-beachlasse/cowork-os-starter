---
name: loop-it
description: Run the evaluator-optimizer loop on a just-built or named deliverable to push its quality up with a trustworthy score. Use when you say "loop it", "loop this", "loop it to N", "loop it, K laps", or "loop it on X". A separate fresh-context evaluator scores the work against a rubric, below-bar work loops back with specific fixes, keep best-so-far, stop at bar/cap/no-progress, and always report the final score and verdict. Defaults: Policy B (aim 100, floor 95, cap 3 laps).
---

# Loop it (evaluator-optimizer)

When you say **"loop it"** (or "loop this", "loop it to N", "loop it, K laps", "loop it on X"), run the evaluator-optimizer cycle on the named or just-built deliverable.

**The cycle:**
1. Draft a rubric from `AI Team/Evaluator-Optimizer Loop/Evaluator Kit.md` (weighted criteria fitting the deliverable).
2. A **separate evaluator** (fresh context — never self-certify; spawn a sub-agent) scores it cold against the rubric and names specific fixes.
3. Below-bar work goes back with those fixes; revise.
4. Repeat — **keep best-so-far** — stopping at bar / cap / no-progress.

**Policy B defaults (override inline):** aim 100, floor 95, cap 3 laps. Keep looping *toward* 100 while laps remain and the score is still climbing — don't bail at the first 95. **Stop early** only at the **target** (100 for objective-check work like code/data; 98 for subjective/taste work, where 98–100 is judge noise) or on **no-progress** (a lap adding < ~2 pts). **At lap 3 stop regardless**, take **best-so-far**, and **always report the final score + verdict** (✓ finished if ≥95, else fell short + best result).

**Trustworthiness:** anchor the evaluator to an **objective check** where one exists (run the code, check the math, corroborate sources) — that's what makes the score real. Near the top the score gets noisy, so for pure-taste work say the top-end is softer. Watch **self-preference bias** when the same model judges its own family's output — Lisa independently re-verifies the winner.

**Right-size:** invoke for high-stakes / quality-critical work, not small one-pass jobs. Full method + reusable rubric: `AI Team/Evaluator-Optimizer Loop/`.
