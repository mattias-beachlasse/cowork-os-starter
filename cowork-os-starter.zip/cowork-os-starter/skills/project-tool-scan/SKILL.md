---
name: project-tool-scan
description: Scout external tools for a project and let you pick. Use when a new project starts, when work hits a genuinely new kind of task (3D, video editing, level editor, etc.), or when you say "scout the tools" / "what tools should we use". Produces an honest options rundown (free/FOSS/freemium/paid, cost stated plainly, good/bad line each) ending in a recommendation — which is allowed to be "just let Claude do this". Never adopts a tool on its own initiative; scans any community skill/plugin/MCP with SkillSpector before install.
---

# Project tool scan — scout, you pick

Run when a **new project starts** or hits a **genuinely new kind of work** (3D, video editing, level editor), or on **"scout the tools."** Default stays "just use Claude / the team."

- **Rundown:** realistic options across free / FOSS / freemium / paid (cost stated honestly, no free-bias), each labelled with a good/bad line, ending in a recommendation (allowed to be "just let Claude do this").
- **High bar:** adopt an external tool only when **materially** better. Never adopt on your own initiative. Scale the scan to the project.
- Read `Free & Open-Source Tools Library.md` first; add new vetted tools there.
- **Safety:** only ever link the **official domain** (copycat sites exist). And **before installing ANY community skill / plugin / MCP, scan it first with SkillSpector** (sandbox, static `--no-llm`) and report the verdict — a CRITICAL / DO_NOT_INSTALL blocks adoption unless you overrides (how-to in the FOSS Library).
